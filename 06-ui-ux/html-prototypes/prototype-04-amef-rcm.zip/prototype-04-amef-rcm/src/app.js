﻿(function(){
  "use strict";
  var steps=window.CMMS_CATALOGS.steps,store=window.CMMS_STORE,demo=window.CMMS_DEMO_CASE,state=store.load(),toastTimer;
  var el=function(id){return document.getElementById(id);};
  function escapeHtml(value){return String(value).replace(/[&<>"']/g,function(c){return({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"})[c];});}
  function renderStepper(){
    el("stepper").innerHTML=steps.map(function(step){
      var active=step.number===state.uiState.currentStep?" active":"",visited=state.uiState.visitedSteps.indexOf(step.number)>=0?" visited":"";
      return '<button class="step-button'+active+visited+'" type="button" data-step="'+step.number+'" aria-current="'+(active?"step":"false")+'"><span class="step-number">'+step.number+'</span><span class="step-copy"><strong>'+escapeHtml(step.title)+'</strong><small>'+escapeHtml(step.short)+'</small></span></button>';
    }).join("");
  }
  function renderContext(){
    var c=state.operationalContext,h=state.analysisHeader;
    el("contextHeader").innerHTML=contextItem("Análisis",h.id+" · Rev. "+h.revision+" · "+h.status)+contextItem("Activo piloto",c.pilotAsset)+contextItem("Sistema",c.system)+contextItem("Configuración",c.configuration)+contextItem("Criticidad",c.criticality);
  }
  function contextItem(label,value){return '<div class="context-item"><span>'+escapeHtml(label)+'</span><strong title="'+escapeHtml(value)+'">'+escapeHtml(value)+'</strong></div>';}
  function renderLanding(){
    var journey=steps.slice(1).map(function(s){return '<div class="journey-item"><strong>'+s.number+' · '+escapeHtml(s.title)+'</strong><span>'+escapeHtml(s.short)+'</span></div>';}).join("");
    el("viewHost").innerHTML='<section class="landing"><div class="landing-intro"><div><span class="eyebrow">Introducción · Paso 0</span><h1>Conservar el razonamiento detrás de cada estrategia de mantenimiento</h1><p class="lead">Este recorrido conecta lo que un activo debe hacer, cómo puede fallar y qué decisión resulta adecuada para su contexto.</p><div class="key-message">AMEF identifica y analiza los fallos. RCM decide qué hacer ante ellos.</div><div class="hero-actions"><button id="startButton" class="button button-primary" type="button">Comenzar análisis →</button><button id="tourButton" class="button button-secondary" type="button">Ver recorrido guiado</button><button class="link-button" type="button" data-rules>Ver datos y reglas</button></div></div><div class="analysis-contrast"><div class="contrast-block"><strong>AMEF · Comprender</strong><p>Ordena funciones, fallos funcionales, modos, causas, efectos y consecuencias.</p></div><div class="contrast-block rcm"><strong>RCM · Decidir</strong><p>Recorre preguntas explícitas para recomendar una tarea, una decisión sin tarea o un análisis pendiente.</p></div></div></div><div class="journey"><h2>Un recorrido, nueve decisiones de análisis</h2><p class="muted">La introducción prepara el contexto; cada etapa posterior conserva entradas, reglas y resultados.</p><div class="journey-grid">'+journey+'</div></div>'+renderCaseBand()+'</section>';
    el("viewFooter").hidden=true;
  }
  function renderCaseBand(){
    var c=demo.operationalContext;
    return '<section class="case-band" aria-labelledby="caseTitle"><div class="case-summary"><span class="eyebrow">Caso conductor</span><h2 id="caseTitle">'+escapeHtml(demo.analysisHeader.title)+'</h2><p>'+escapeHtml(c.plant)+' · '+escapeHtml(c.subsystem)+'</p></div><div class="case-fact"><span class="eyebrow">Activos</span><strong>'+c.pilotAsset+' / '+c.redundantAsset+'</strong><p>'+escapeHtml(c.configuration)+'</p></div><div class="case-fact"><span class="eyebrow">Servicio</span><strong>'+escapeHtml(c.service)+'</strong><p>Régimen '+escapeHtml(c.regime.toLowerCase())+'</p></div><div class="case-fact"><span class="eyebrow">Contexto inicial</span><strong>Criticidad '+escapeHtml(c.criticality.toLowerCase())+'</strong><p>Pérdida de caudal puede reducir producción.</p></div></section>';
  }
  function renderStep(step){
    var inputItems=step.inputs.map(function(i){return "<li>"+escapeHtml(i)+"</li>";}).join(""),outputItems=step.outputs.map(function(i){return "<li>"+escapeHtml(i)+"</li>";}).join("");
    el("viewHost").innerHTML='<section class="step-view"><header class="step-heading"><div><span class="eyebrow">Paso '+step.number+' · '+escapeHtml(step.short)+'</span><h1>'+escapeHtml(step.question)+'</h1><p>'+escapeHtml(step.why)+'</p></div><span class="stage-badge">Se implementa en '+escapeHtml(step.sprint)+'</span></header><section class="why-panel"><h2>Por qué importa</h2><p>'+escapeHtml(step.why)+'</p></section><div class="placeholder-grid"><section class="placeholder-panel"><h2>Información prevista</h2><ul class="item-list">'+inputItems+'</ul></section><section class="placeholder-panel"><h2>Resultado que alimentará el siguiente paso</h2><ul class="item-list">'+outputItems+'</ul></section></div><div class="future-note"><strong>Placeholder funcional:</strong> la navegación y el contrato de esta etapa están activos. Sus formularios, tablas y validaciones se incorporarán en '+escapeHtml(step.sprint)+'.</div><button class="link-button" type="button" data-rules>Ver datos y reglas</button></section>';
    el("viewFooter").hidden=false;el("backButton").disabled=false;el("nextButton").disabled=step.number===steps.length-1;el("stepPosition").textContent="Paso "+step.number+" de 9";el("nextButton").textContent=step.number===steps.length-1?"Fin del recorrido":"Siguiente →";
  }
  function render(){
    state=store.get();renderStepper();renderContext(); if(state.uiState.currentStep===0)renderLanding(); else if(state.uiState.currentStep<=9){var module=state.uiState.currentStep<=4?window.CMMS_P042:(state.uiState.currentStep<=6?window.CMMS_P043:(state.uiState.currentStep<=8?window.CMMS_P044:window.CMMS_P045));el("viewHost").innerHTML=module.render(state.uiState.currentStep,state);el("viewFooter").hidden=false;el("backButton").disabled=false;el("nextButton").disabled=state.uiState.currentStep===9;el("stepPosition").textContent="Paso "+state.uiState.currentStep+" de 9";el("nextButton").textContent=state.uiState.currentStep===9?"Fin del recorrido":"Siguiente →";} else renderStep(steps[state.uiState.currentStep]); renderSaveState();renderScenarioControl();bindDynamic();window.CMMS_P046.decorate(state);applyReadOnly();document.title="CMMS 2.0 · "+steps[state.uiState.currentStep].title;
  }
  function bindDynamic(){
    var start=el("startButton"),tour=el("tourButton");if(start){start.addEventListener("click",function(){goTo(1);});}if(tour){tour.addEventListener("click",openTour);}
    Array.prototype.forEach.call(document.querySelectorAll("[data-rules]"),function(button){button.addEventListener("click",openDrawer);});
    if(state.uiState.currentStep>=1&&state.uiState.currentStep<=9)(state.uiState.currentStep<=4?window.CMMS_P042:(state.uiState.currentStep<=6?window.CMMS_P043:(state.uiState.currentStep<=8?window.CMMS_P044:window.CMMS_P045))).bind(state.uiState.currentStep,state,render,showToast);
  }
  function goTo(step){if(step<0||step>=steps.length)return;if(step>state.uiState.currentStep&&state.uiState.currentStep>=1&&state.uiState.currentStep<=9){var validator=state.uiState.currentStep<=4?window.CMMS_P042:(state.uiState.currentStep<=6?window.CMMS_P043:(state.uiState.currentStep<=8?window.CMMS_P044:window.CMMS_P045));var check=validator.validate(state.uiState.currentStep,state);if(!check.valid){showToast(check.errors[0]);return;}}store.setStep(step);closeMenu();render();el("mainContent").focus();}
  function applyReadOnly(){var readonly=window.CMMS_P046.isReadonly(state);document.body.classList.toggle("readonly-mode",readonly);if(!readonly)return;Array.prototype.forEach.call(document.querySelectorAll("#viewHost input,#viewHost select,#viewHost textarea,#viewHost button"),function(control){if(control.id!=="createRevision"&&!control.hasAttribute("data-review-tab")&&!control.hasAttribute("data-rules"))control.disabled=true;});}
  function renderScenarioControl(){var select=el("scenarioSelect");select.innerHTML=window.CMMS_P046_SCENARIOS.map(function(x){return "<option value=\""+x.id+"\""+(x.id===(state.uiState.demoScenario||"complete")?" selected":"")+">"+escapeHtml(x.label)+"</option>";}).join("");}
  function renderSaveState(){var s=el("saveState");if(state.uiState.dirty){s.textContent="Cambios sin guardar";return;}s.textContent=state.uiState.lastSavedAt?"Guardado localmente":"Sin cambios";}
  function showToast(message){var t=el("toast");t.textContent=message;t.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(function(){t.hidden=true;},2600);}
  function openDrawer(){
    var step=steps[state.uiState.currentStep];
    el("drawerContent").innerHTML='<section class="rule-group"><h3>Entidad conceptual</h3><p>'+escapeHtml(step.entity)+'</p></section><section class="rule-group"><h3>Clasificación de la información</h3><dl class="definition-list"><div><dt>Origen</dt><dd>Caso conductor y configuración de demostración.</dd></div><div><dt>Obligatoriedad</dt><dd>Se detallará con las validaciones del '+escapeHtml(step.sprint)+'.</dd></div><div><dt>Regla</dt><dd>'+escapeHtml(step.why)+'</dd></div><div><dt>Salida</dt><dd>'+escapeHtml(step.outputs.join("; "))+'</dd></div><div><dt>Pendiente para IT</dt><dd>Persistencia, identidad, auditoría e integración productiva.</dd></div></dl></section>';
    el("drawerBackdrop").hidden=false;el("rulesDrawer").classList.add("open");el("rulesDrawer").setAttribute("aria-hidden","false");setTimeout(function(){el("closeDrawerButton").focus();},0);
  }
  function closeDrawer(){el("rulesDrawer").classList.remove("open");el("rulesDrawer").setAttribute("aria-hidden","true");el("drawerBackdrop").hidden=true;}
  function openTour(){el("tourContent").innerHTML=steps.slice(1).map(function(s){return '<div class="tour-step"><strong>'+s.number+' · '+escapeHtml(s.title)+'</strong><span>'+escapeHtml(s.short)+'</span></div>';}).join("");el("tourDialog").showModal();}
  function toggleMenu(){var open=!el("sidebar").classList.contains("open");el("sidebar").classList.toggle("open",open);el("menuButton").setAttribute("aria-expanded",String(open));}
  function closeMenu(){el("sidebar").classList.remove("open");el("menuButton").setAttribute("aria-expanded","false");}
  function bindStatic(){
    el("scenarioSelect").addEventListener("change",function(){var scenario=window.CMMS_P046.get(this.value);state.uiState.demoScenario=scenario.id;if(scenario.step!==null){state.uiState.currentStep=scenario.step;if(state.uiState.visitedSteps.indexOf(scenario.step)<0)state.uiState.visitedSteps.push(scenario.step);}render();});
    el("stepper").addEventListener("click",function(e){var button=e.target.closest("[data-step]");if(button)goTo(Number(button.dataset.step));});
    el("backButton").addEventListener("click",function(){goTo(state.uiState.currentStep-1);});el("nextButton").addEventListener("click",function(){goTo(state.uiState.currentStep+1);});
    el("saveButton").addEventListener("click",function(){if(store.save()){state=store.get();renderSaveState();showToast("Borrador guardado en este navegador.");}else{showToast("No se pudo guardar. La demo puede continuar.");}});
    el("resetButton").addEventListener("click",function(){el("resetDialog").showModal();});el("cancelResetButton").addEventListener("click",function(){el("resetDialog").close();});
    el("confirmResetButton").addEventListener("click",function(){store.reset();el("resetDialog").close();render();showToast("Demostración reiniciada.");});
    el("menuButton").addEventListener("click",toggleMenu);el("closeDrawerButton").addEventListener("click",closeDrawer);el("drawerBackdrop").addEventListener("click",closeDrawer);
    el("closeTourButton").addEventListener("click",function(){el("tourDialog").close();});el("tourStartButton").addEventListener("click",function(){el("tourDialog").close();goTo(1);});
    document.addEventListener("keydown",function(e){if(e.key==="Escape"){closeDrawer();closeMenu();}});
  }
  bindStatic();render();
})();
